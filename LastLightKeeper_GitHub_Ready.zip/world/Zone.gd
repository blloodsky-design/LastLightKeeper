extends Node2D
class_name GameZone

@export var zone_id: String = "solferino"
var zone_title := ""
var zone_subtitle := ""
var mechanic := ""
var enemy_count := 0
var boss_id := ""
var boss_title := ""
var boss_defeated := false
var player: Player
var bounds := Rect2(80, 80, 1760, 920)
var hazard_timer := 0.0
var spawn_points: Array[Vector2] = []
signal boss_completed(id: String, zone_id: String)

const ZONES := {
	"solferino": {"title":"Долина Сольферино", "subtitle":"Стабильный свет. Первые тени.", "mechanic":"Укрытия восстанавливают свет", "enemy":"shade", "count":7, "boss":"forge_guardian", "boss_title":"Страж Горнила Судеб", "color":Color("#182a42")},
	"whispering_forest": {"title":"Шепчущий Лес", "subtitle":"Деревья слышат каждый шаг.", "mechanic":"Живые тени преследуют движущегося", "enemy":"living_shadow", "count":9, "boss":"root_mother", "boss_title":"Матерь Корней", "color":Color("#241c3d")},
	"glass_wastes": {"title":"Стеклянные Пустоши", "subtitle":"Свет возвращается с чужого угла.", "mechanic":"Отражённые лучи раскрывают невидимых врагов", "enemy":"mirror_wraith", "count":10, "boss":"crystal_scorpion", "boss_title":"Кристаллический Скорпион", "color":Color("#3a2636")},
	"sunken_archipelago": {"title":"Затонувший Архипелаг", "subtitle":"Город под водой всё ещё жив.", "mechanic":"Подводные фонари показывают монстров", "enemy":"drowned", "count":11, "boss":"tide_colossus", "boss_title":"Колосс Прилива", "color":Color("#102f42")},
	"void_citadel": {"title":"Цитадель Пустоты", "subtitle":"Свет умирает вдвое быстрее.", "mechanic":"Удвоенный расход света", "enemy":"voidling", "count":13, "boss":"nigil", "boss_title":"Нигил — Чёрное Солнце", "color":Color("#180f20")}
}

func _ready() -> void:
	var cfg: Dictionary = ZONES.get(zone_id, ZONES["solferino"])
	zone_title = cfg.title
	zone_subtitle = cfg.subtitle
	mechanic = cfg.mechanic
	enemy_count = int(cfg.count)
	boss_id = cfg.boss
	boss_title = cfg.boss_title
	boss_defeated = GameState.is_boss_defeated(boss_id)
	spawn_points = _make_spawn_points(enemy_count)
	_create_player()
	_create_enemies(cfg.enemy)
	if not boss_defeated:
		_create_boss()
	queue_redraw()

func _make_spawn_points(count: int) -> Array[Vector2]:
	var result: Array[Vector2] = []
	for i in count:
		var angle := float(i) / max(1, count) * TAU
		result.append(Vector2(960, 540) + Vector2(cos(angle), sin(angle)) * (260.0 + float(i % 3) * 100.0))
	return result

func _create_player() -> void:
	player = Player.new()
	player.position = Vector2(960, 540)
	player.zone_id = zone_id
	add_child(player)

func _create_enemies(enemy_type: String) -> void:
	for i in enemy_count:
		var e := Enemy.new()
		e.enemy_type = enemy_type
		e.level = 1 + i / 4
		e.position = spawn_points[i]
		add_child(e)

func _create_boss() -> void:
	var boss := Boss.new()
	boss.boss_id = boss_id
	boss.boss_title = boss_title
	boss.position = Vector2(1540, 540)
	boss.zone_id = zone_id
	boss.boss_defeated.connect(_on_boss_defeated)
	add_child(boss)

func _on_boss_defeated(id: String) -> void:
	boss_defeated = true
	GameState.mark_boss_defeated(id)
	var quest_map := {"solferino":"q_first_light", "whispering_forest":"q_living_shadows", "glass_wastes":"q_reflection", "sunken_archipelago":"q_drowned_memory", "void_citadel":"q_black_sun"}
	if quest_map.has(zone_id):
		StoryManager.complete_quest(quest_map[zone_id])
	var achievement_map := {"forge_guardian":"forge_slayer", "root_mother":"forest_slayer", "crystal_scorpion":"crystal_hunter", "tide_colossus":"tidebreaker", "nigil":"last_sun"}
	if achievement_map.has(id):
		StatsManager.register_action("achievement_" + str(achievement_map[id]))
	if id == "nigil":
		GameState.set_flag("eternal_twilight_ended", true)
	var next := _next_zone()
	if next != "":
		GameState.unlock_zone(next)
	GameState.add_experience(150)
	GameState.add_gold(100)
	GameState.add_item("ancient_coin" if zone_id == "sunken_archipelago" else "light_shard", 3)
	if id == "forge_guardian": GameState.unlock_recipe("sunsteel_blade")
	if id == "root_mother": GameState.unlock_recipe("shadow_ward")
	boss_completed.emit(id, zone_id)
	queue_redraw()

func _next_zone() -> String:
	var order := ["solferino", "whispering_forest", "glass_wastes", "sunken_archipelago", "void_citadel"]
	var idx := order.find(zone_id)
	return order[idx + 1] if idx >= 0 and idx + 1 < order.size() else ""

func _process(delta: float) -> void:
	hazard_timer += delta
	if player == null:
		return
	if zone_id == "void_citadel":
		player.light_drain_multiplier = 2.0
	elif zone_id == "whispering_forest":
		player.light_drain_multiplier = 1.15
	else:
		player.light_drain_multiplier = 1.0
	if zone_id == "sunken_archipelago" and fmod(hazard_timer, 5.0) < delta:
		player.restore_light(8.0)
	if zone_id == "glass_wastes" and fmod(hazard_timer, 3.5) < delta:
		for e in get_tree().get_nodes_in_group("enemies"):
			if is_instance_valid(e):
				e.reflected = true

func _draw() -> void:
	var cfg: Dictionary = ZONES.get(zone_id, ZONES["solferino"])
	draw_rect(bounds, cfg.color, true)
	for x in range(120, 1810, 140):
		for y in range(120, 950, 140):
			var p := Vector2(x, y)
			if zone_id == "glass_wastes":
				draw_colored_polygon(PackedVector2Array([p + Vector2(-22, 18), p + Vector2(0,-28), p + Vector2(28,12), p + Vector2(5,35)]), Color("#79566e"))
			elif zone_id == "whispering_forest":
				draw_circle(p, 30, Color("#332650"))
				draw_rect(Rect2(p + Vector2(-8,20), Vector2(16,65)), Color("#46313d"))
			elif zone_id == "sunken_archipelago":
				draw_rect(Rect2(p - Vector2(48, 18), Vector2(96, 36)), Color("#204b60"), true)
			elif zone_id == "void_citadel":
				draw_rect(Rect2(p - Vector2(24,24), Vector2(48,48)), Color("#30192f"), true)
			else:
				draw_circle(p, 22, Color("#263e4f"))
	if zone_id == "void_citadel":
		for i in range(8):
			var p := Vector2(180 + i * 220, 160 + (i % 2) * 680)
			draw_line(p, p + Vector2(80, -120), Color("#9a3158", 0.35), 5.0)
	draw_circle(Vector2(960,540), 130, Color("#f3d06d", 0.04))
