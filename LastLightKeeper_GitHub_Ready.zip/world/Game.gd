extends Node2D
class_name GameController

signal finished

const ZONE_SCENES := {
	"solferino":"res://scenes/zones/Solferino.tscn",
	"whispering_forest":"res://scenes/zones/WhisperingForest.tscn",
	"glass_wastes":"res://scenes/zones/GlassWastes.tscn",
	"sunken_archipelago":"res://scenes/zones/SunkenArchipelago.tscn",
	"void_citadel":"res://scenes/zones/VoidCitadel.tscn"
}
var zone: GameZone
var hud: GameHUD
var final_scene: FinalScene

func _ready() -> void:
	load_zone(GameState.current_zone)

func load_zone(zone_id: String) -> void:
	if not GameState.is_zone_unlocked(zone_id):
		zone_id = "solferino"
	GameState.current_zone = zone_id
	GameState.save_game()
	if zone:
		zone.queue_free()
	zone = load(ZONE_SCENES[zone_id]).instantiate()
	zone.boss_completed.connect(_on_boss_completed)
	add_child(zone)
	if hud == null:
		hud = GameHUD.new()
		add_child(hud)
	hud.bind_game(self)
	hud.show_zone(zone)

func open_world_map() -> void: hud.show_world_map(self)
func open_inventory() -> void: hud.show_inventory(self)
func open_crafting() -> void: hud.show_crafting(self)
func open_settings() -> void: hud.show_settings(self)
func return_to_zone() -> void: hud.show_zone(zone)

func craft_item(recipe_id: String) -> void:
	var recipes := {
		"light_potion":{"ingredients":{"light_shard":2,"herb":1},"result":"light_potion"},
		"sunsteel_blade":{"ingredients":{"light_shard":3,"ancient_coin":2},"result":"sunsteel_blade"},
		"shadow_ward":{"ingredients":{"dark_iron":2,"light_shard":4},"result":"shadow_ward"}
	}
	if not recipes.has(recipe_id): return
	var r: Dictionary = recipes[recipe_id]
	if GameState.craft(recipe_id, r.ingredients, r.result, 1):
		if recipe_id == "sunsteel_blade": GameState.player_damage += 8.0
		if recipe_id == "shadow_ward": GameState.player_max_health += 25.0
		if GameState.crafted_items.size() >= 3:
			StatsManager.register_action("achievement_master_crafter")
		GameState.save_game()
		hud.show_crafting(self)

func _on_boss_completed(id: String, zone_id: String) -> void:
	if id == "nigil":
		GameState.set_flag("eternal_twilight_ended", true)
		GameState.current_zone = "void_citadel"
		GameState.save_game()
		call_deferred("_show_final")

func _show_final() -> void:
	if final_scene: final_scene.queue_free()
	final_scene = FinalScene.new()
	add_child(final_scene)
	final_scene.setup()
	final_scene.closed.connect(_finish_game)

func _finish_game() -> void:
	GameState.save_game()
	finished.emit()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and hud and hud.is_overlay_open():
		hud.show_zone(zone)
