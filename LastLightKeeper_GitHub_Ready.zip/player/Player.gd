extends CharacterBody2D
class_name Player

@export var move_speed: float = 260.0
var max_light: float
var light_energy: float
var health: float
var max_health: float
var damage: float
var mobile_axis := Vector2.ZERO
var light_drain_multiplier := 1.0
var zone_id := "solferino"
var attack_cooldown := 0.0
var invulnerable := 0.0
signal health_changed(current: float, maximum: float)
signal light_changed(current: float, maximum: float)
signal attacked
signal died

func _ready() -> void:
	add_to_group("player")
	max_health = GameState.player_max_health
	health = max_health
	max_light = GameState.player_light_max
	light_energy = max_light
	damage = GameState.player_damage
	queue_redraw()

func _physics_process(delta: float) -> void:
	var keyboard_axis := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	var axis := mobile_axis if mobile_axis.length() > 0.05 else keyboard_axis
	velocity = axis.limit_length(1.0) * move_speed
	move_and_slide()
	position.x = clamp(position.x, 100.0, 1820.0)
	position.y = clamp(position.y, 100.0, 980.0)
	attack_cooldown = max(0.0, attack_cooldown - delta)
	invulnerable = max(0.0, invulnerable - delta)
	if light_energy > 0.0:
		light_energy = max(0.0, light_energy - 2.0 * light_drain_multiplier * delta)
	light_changed.emit(light_energy, max_light)
	if Input.is_action_just_pressed("attack"):
		light_attack()
	queue_redraw()

func set_mobile_axis(value: Vector2) -> void:
	mobile_axis = value.limit_length(1.0)

func restore_light(amount: float) -> void:
	light_energy = min(max_light, light_energy + amount)
	light_changed.emit(light_energy, max_light)

func has_light() -> bool:
	return light_energy > 0.0

func light_attack() -> void:
	if attack_cooldown > 0.0 or light_energy < 4.0:
		return
	attack_cooldown = 0.38
	light_energy = max(0.0, light_energy - 4.0)
	var aim := Vector2.RIGHT
	var enemies := get_tree().get_nodes_in_group("enemies")
	for target in enemies:
		if not is_instance_valid(target):
			continue
		var distance: float = global_position.distance_to(target.global_position)
		if distance <= 230.0:
			target.take_damage(damage * (1.5 if target.reflected else 1.0))
	attacked.emit()
	light_changed.emit(light_energy, max_light)

func take_damage(amount: float) -> void:
	if amount <= 0.0:
		health = min(max_health, health - amount)
		health_changed.emit(health, max_health)
		return
	if invulnerable > 0.0:
		return
	invulnerable = 0.45
	health = max(0.0, health - amount)
	health_changed.emit(health, max_health)
	if health <= 0.0:
		died.emit()
		health = max_health
		light_energy = max_light
		position = Vector2(960, 540)

func _draw() -> void:
	draw_circle(Vector2.ZERO, 22, Color("#f5d98a"))
	draw_circle(Vector2.ZERO, 31, Color("#f7dc87", 0.10))
	draw_line(Vector2.ZERO, Vector2(38,0), Color("#fff4c2",0.65), 5.0)
