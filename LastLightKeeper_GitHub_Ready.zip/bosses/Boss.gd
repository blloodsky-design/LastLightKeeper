extends CharacterBody2D
class_name Boss

var boss_id := "forge_guardian"
var boss_title := "Boss"
var zone_id := "solferino"
var max_health := 420.0
var health := 420.0
var damage := 15.0
var speed := 45.0
var timer := 0.0
var phase := 1
var enraged := false
signal boss_defeated(id: String)

func _ready() -> void:
	add_to_group("enemies")
	var scale := {"forge_guardian":1.0,"root_mother":1.15,"crystal_scorpion":1.25,"tide_colossus":1.4,"nigil":1.7}.get(boss_id,1.0)
	max_health *= scale
	health = max_health
	damage *= scale
	queue_redraw()

func _physics_process(delta: float) -> void:
	var p := get_tree().get_first_node_in_group("player") as Node2D
	if p == null:
		return
	timer += delta
	var dir := global_position.direction_to(p.global_position)
	velocity = dir * (speed * (1.45 if enraged else 1.0))
	move_and_slide()
	if global_position.distance_to(p.global_position) < 75.0 and fmod(timer, 1.1) < delta:
		p.take_damage(damage)
	if fmod(timer, 3.2) < delta:
		_special_attack(p)
	if health < max_health * 0.5 and not enraged:
		enraged = true
		phase = 2
	queue_redraw()

func _special_attack(p: Node2D) -> void:
	match boss_id:
		"forge_guardian":
			p.take_damage(damage * 0.8)
		"root_mother":
			p.take_damage(damage * 1.1)
		"crystal_scorpion":
			if not p.has_light():
				p.take_damage(damage * 1.8)
			else:
				p.take_damage(damage * 0.6)
		"tide_colossus":
			p.take_damage(damage * 1.25)
		"nigil":
			p.take_damage(damage * (2.0 if phase == 2 else 1.0))

func take_damage(amount: float) -> void:
	health -= amount
	if health <= 0.0:
		boss_defeated.emit(boss_id)
		queue_free()

func _draw() -> void:
	var c := Color("#c7824a")
	match boss_id:
		"root_mother": c = Color("#8b5e9e")
		"crystal_scorpion": c = Color("#d07db7")
		"tide_colossus": c = Color("#3c9cb0")
		"nigil": c = Color("#b82f5d")
	draw_circle(Vector2.ZERO, 52, c)
	draw_circle(Vector2.ZERO, 72, Color(c, 0.10))
	draw_rect(Rect2(-65,-82,130,8), Color("#100c15"), true)
	draw_rect(Rect2(-65,-82,130 * clamp(health/max_health,0.0,1.0),8), Color("#efc765"), true)
