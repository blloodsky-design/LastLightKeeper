# Android UI finalization

- Safe Area with Android display insets.
- Adaptive touch-button sizing.
- Landscape canvas scaling.
- Responsive compact/standard/wide aspect-ratio detection.
- Reusable AndroidHUD with safe top bar, joystick area and action buttons.
- Ending screen root configured to fill the viewport.
- Designed for 18:9, 19.5:9, 20:9+ and tablets.

Source project only: no APK/AAB was generated.
