# Last Light Keeper — Android Vertical Slice

Готовый игровой вертикальный срез на Godot 4.x для Android.

## Уже реализовано
- 5 отдельных сцен биомов:
  - Долина Сольферино
  - Шепчущий Лес
  - Стеклянные Пустоши
  - Затонувший Архипелаг
  - Цитадель Пустоты
- Разные механики биомов и визуальные схемы.
- Управление клавиатурой + виртуальный джойстик + сенсорная кнопка света.
- Бой: ближний световой удар, урон, здоровье, смерть/возрождение, AI врагов.
- 5 боссов с отдельными фазами/модификаторами.
- Прогрессия: опыт, уровни, урон, HP, запас света.
- Карта мира с блокировкой/разблокировкой биомов.
- Инвентарь с реальными предметами и сохранением.
- Крафт 3 предметов, меняющих характеристики игрока.
- Лут с врагов и награды боссов.
- Сохранение в user://savegame.json.
- Android Safe Area и адаптивный HUD.

## Запуск
Открой проект в Godot 4.x и запусти `scenes/Main.tscn`.

## Android
Установи Android SDK/JDK и export templates в Godot. Для Play Store используй собственный release keystore.


## Persistent Save System

Save data is stored in `user://savegame.json` with a versioned schema. The game saves current zone, defeated bosses, unlocked zones, inventory, gold, level/XP, crafted and unlocked recipes, derived player stats, and Android control settings. Saves are written through a temporary file and keep a backup copy so an interrupted write can recover on next launch. Version 1 saves are migrated automatically.
