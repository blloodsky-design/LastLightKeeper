# Last Light Keeper — GitHub APK Build

Этот репозиторий подготовлен для облачной сборки Android APK.

## Сборка с телефона

1. Создай пустой GitHub repository `LastLightKeeper`.
2. Загрузи **все файлы и папки этого архива** в корень repository.
3. Открой `Actions`.
4. Выбери `Build Android APK`.
5. Нажми `Run workflow`.
6. Дождись завершения.
7. Открой завершённый workflow.
8. Внизу страницы скачай artifact `LastLightKeeper-debug-apk`.
9. Распакуй ZIP и установи `LastLightKeeper-debug.apk`.

Это debug APK для тестирования на телефоне. Для публикации в Google Play понадобится отдельная release-сборка с ключом подписи.
