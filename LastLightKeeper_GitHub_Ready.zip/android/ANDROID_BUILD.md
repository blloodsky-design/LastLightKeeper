# Android build

The project is configured for a landscape Android build and uses the Compatibility renderer.

## Safe Area

All mobile HUD elements are placed inside `ui/SafeArea.gd`, which accounts for display cutouts, navigation/gesture areas and window resizing. UI uses anchors and containers instead of fixed screen coordinates.

## Godot setup

1. Install Godot 4.x.
2. In **Editor Settings → Export → Android**, configure OpenJDK and Android SDK/Build Tools.
3. Install the Android export templates matching the Godot version.
4. Open the project and select **Project → Export → Android Debug**.
5. The preset targets `arm64-v8a` and package `com.lastlightkeeper.game`.

## Release APK/AAB

A release build requires a signing keystore. No private keystore is stored in this project. For Google Play, create a release keystore and configure it in the Android export settings.

## Important

This repository is the Android-ready project foundation. An APK is not bundled because an APK cannot be honestly produced without a working Godot Android export toolchain (Godot editor/templates + Android SDK/JDK) and, for release distribution, signing credentials.
