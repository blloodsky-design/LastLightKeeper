extends Area2D
class_name OreNode

@export var ore_type: String = "iron_ore"
@export_range(1.0, 300.0, 1.0) var respawn_time: float = 30.0
@export_range(1, 20, 1) var max_hits: int = 3
@export var harvest_amount: int = 1

@onready var timer: Timer = $Timer
var current_hits: int = 0
var is_active: bool = true

func _ready() -> void:
	if timer == null:
		push_error("OreNode: Timer child is missing.")
		return
	timer.wait_time = respawn_time
	timer.one_shot = true
	if not timer.timeout.is_connected(_on_respawn_timeout):
		timer.timeout.connect(_on_respawn_timeout)

func interact() -> void:
	if not is_active:
		return
	current_hits += 1
	if current_hits >= max_hits:
		_harvest()

func _harvest() -> void:
	is_active = false
	current_hits = 0
	visible = false
	monitoring = false
	monitorable = false
	GameState.add_item(ore_type, harvest_amount)
	StatsManager.register_action("first_ore")
	timer.start()

func _on_respawn_timeout() -> void:
	is_active = true
	current_hits = 0
	visible = true
	monitoring = true
	monitorable = true
