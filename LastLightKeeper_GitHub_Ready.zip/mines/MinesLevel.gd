extends Node2D
class_name MinesLevel

@export var level_depth: int = 1
@onready var spawn_point: Marker2D = $SpawnPoint

func _ready() -> void:
	add_to_group("mines_level")
	call_deferred("_spawn_player")

func _spawn_player() -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		push_warning("MinesLevel: player not found in group 'player'.")
		return
	if spawn_point == null:
		push_error("MinesLevel: SpawnPoint is missing.")
		return
	player.global_position = spawn_point.global_position
