extends CharacterBody2D
class_name CaveBat

@export var speed: float = 110.0
@export var max_hp: int = 25
@export var contact_damage: int = 8
var hp: int
var target: Node2D

func _ready() -> void:
	hp = max_hp
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty():
		target = players[0] as Node2D

func _physics_process(_delta: float) -> void:
	if not is_instance_valid(target):
		velocity = Vector2.ZERO
		return
	velocity = global_position.direction_to(target.global_position) * speed
	move_and_slide()

func take_damage(amount: int) -> void:
	if amount <= 0:
		return
	hp -= amount
	if hp <= 0:
		queue_free()
