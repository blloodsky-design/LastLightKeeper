extends CharacterBody2D
class_name StoneGolem

@export var speed: float = 40.0
@export var max_hp: int = 180
@export var damage: int = 22
var hp: int

func _ready() -> void:
	hp = max_hp
	add_to_group("miniboss")

func take_damage(amount: int) -> void:
	if amount <= 0:
		return
	hp -= amount
	if hp <= 0:
		die()

func die() -> void:
	GameState.set_flag("stone_golem_defeated", true)
	StatsManager.register_action("golem_slayer")
	var enemy := DataManager.get_entry("enemies", "stone_golem")
	GameState.add_experience(int(enemy.get("exp", 0)))
	queue_free()
