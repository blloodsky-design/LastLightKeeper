extends Node
## Story flow hooks for the full game.
func begin_new_game() -> void:
    GameState.start_new_game()
    StoryManager.reset_for_new_game()
    GameState.save_game()

func should_show_intro() -> bool:
    return not StoryManager.intro_seen

func finish_intro() -> void:
    StoryManager.mark_intro_seen()

func on_boss_defeated(zone: String) -> void:
    var map := {
        "solferino":"q_first_light",
        "whispering_forest":"q_living_shadows",
        "glass_wastes":"q_reflection",
        "sunken_archipelago":"q_drowned_memory",
        "void_citadel":"q_black_sun"
    }
    if map.has(zone):
        StoryManager.complete_quest(map[zone])

func rescue_npc(id: String) -> void:
    StoryManager.rescue_npc(id)

func finish_finale() -> Dictionary:
    GameState.set_flag("game_completed", true)
    var ending := StoryManager.evaluate_ending()
    GameState.save_game()
    return ending
