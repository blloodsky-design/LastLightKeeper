extends Control
## Lightweight mobile-friendly dialogue panel.
@onready var speaker_label: Label = $Panel/VBox/Speaker
@onready var text_label: Label = $Panel/VBox/Text
@onready var next_button: Button = $Panel/VBox/Next

var lines: Array = []
var index := 0
var on_finished: Callable

func start(dialogue_lines: Array, finished: Callable = Callable()) -> void:
    lines = dialogue_lines
    index = 0
    on_finished = finished
    visible = true
    _show_line()

func _show_line() -> void:
    if index >= lines.size():
        visible = false
        if on_finished.is_valid():
            on_finished.call()
        return
    var line: Dictionary = lines[index]
    speaker_label.text = str(line.get("speaker",""))
    text_label.text = str(line.get("text",""))

func _on_next_pressed() -> void:
    index += 1
    _show_line()
