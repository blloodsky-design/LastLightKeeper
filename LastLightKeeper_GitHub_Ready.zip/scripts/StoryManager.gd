extends Node
## Story, choices, rescued NPCs and ending evaluation.
var story: Dictionary = {}
var intro_seen := false
var completed_quests: Array[String] = []
var discovered_lore: Array[String] = []
var dialogue_seen: Array[String] = []
var decisions: Dictionary = {}
var quest_variants: Dictionary = {}
var rescued_npcs: Array[String] = []
var final_ending := ""
var discovered_endings: Array[String] = []

func _ready() -> void:
    _load_story()
    _restore()

func _load_story() -> void:
    var f := FileAccess.open("res://data/story.json", FileAccess.READ)
    if f:
        var parsed = JSON.parse_string(f.get_as_text())
        if parsed is Dictionary:
            story = parsed

func _restore() -> void:
    if not GameState.story.is_empty():
        var s: Dictionary = GameState.story
        intro_seen = bool(s.get("intro_seen", false))
        completed_quests = Array(s.get("completed_quests", []))
        discovered_lore = Array(s.get("discovered_lore", []))
        dialogue_seen = Array(s.get("dialogue_seen", []))
        decisions = Dictionary(s.get("decisions", {}))
        quest_variants = Dictionary(s.get("quest_variants", {}))
        rescued_npcs = Array(s.get("rescued_npcs", []))
        final_ending = str(s.get("final_ending", ""))
        discovered_endings = Array(s.get("discovered_endings", []))

func save() -> void:
    GameState.story = {
        "intro_seen": intro_seen,
        "completed_quests": completed_quests,
        "discovered_lore": discovered_lore,
        "dialogue_seen": dialogue_seen,
        "decisions": decisions,
        "quest_variants": quest_variants,
        "rescued_npcs": rescued_npcs,
        "final_ending": final_ending,
        "discovered_endings": discovered_endings
    }
    GameState.save_game()

func reset_for_new_game() -> void:
    intro_seen = false
    completed_quests.clear()
    discovered_lore.clear()
    dialogue_seen.clear()
    decisions.clear()
    quest_variants.clear()
    rescued_npcs.clear()
    final_ending = ""
    # discovered_endings intentionally survives a new run for meta completion.
    save()

func mark_intro_seen() -> void:
    intro_seen = true
    save()

func record_decision(dialogue_id: String, choice_id: String, set_values: Dictionary, quest_effect: Dictionary = {}) -> void:
    decisions[dialogue_id] = choice_id
    for key in set_values:
        decisions[key] = set_values[key]
    for quest_id in quest_effect:
        quest_variants[quest_id] = quest_effect[quest_id]
    save()

func rescue_npc(id: String) -> void:
    if not rescued_npcs.has(id):
        rescued_npcs.append(id)
        save()

func get_rescued_count() -> int:
    return rescued_npcs.size()

func get_decision(dialogue_id: String) -> String:
    return str(decisions.get(dialogue_id, ""))

func get_story_flag(key: String, default_value = null):
    return decisions.get(key, default_value)

func get_quest_variant(id: String) -> String:
    return str(quest_variants.get(id, ""))

func complete_quest(id: String) -> void:
    if not completed_quests.has(id):
        completed_quests.append(id)
        save()

func discover_lore(id: String) -> void:
    if not discovered_lore.has(id):
        discovered_lore.append(id)
        save()

func mark_dialogue_seen(id: String) -> void:
    if not dialogue_seen.has(id):
        dialogue_seen.append(id)
        save()

func get_branching_dialogue(id: String) -> Dictionary:
    for d in story.get("branching_dialogues", []):
        if d.get("id","") == id:
            return d
    return {}

func get_quest(id: String) -> Dictionary:
    for q in story.get("quests", []):
        if q.get("id","") == id:
            return q
    return {}

func get_lore(id: String) -> Dictionary:
    for l in story.get("lore", []):
        if l.get("id","") == id:
            return l
    return {}

func get_npcs_for_zone(zone: String) -> Array:
    var result: Array = []
    for n in story.get("npcs", []):
        if n.get("zone","") == zone:
            result.append(n)
    return result

func _conditions_match(c: Dictionary, ending_choice: String) -> bool:
    if str(c.get("ending_choice","")) != "" and str(c.get("ending_choice","")) != ending_choice:
        return false
    if rescued_npcs.size() < int(c.get("min_saved_npcs",0)):
        return false
    if completed_quests.size() < int(c.get("min_completed_quests",0)):
        return false
    for flag in ["mercy","resolve","forest_mercy"]:
        if c.has(flag) and int(decisions.get(flag,0)) != int(c[flag]):
            return false
    return true

func evaluate_ending() -> Dictionary:
    var ending_choice := str(decisions.get("nigil_final_choice",""))
    # Explicitly support the final choice stored by BranchingDialogue.
    if ending_choice == "":
        ending_choice = str(decisions.get("ending",""))

    var fallback: Dictionary = {}
    for rule in story.get("ending_rules", []):
        var conditions: Dictionary = Dictionary(rule.get("conditions", {}))
        if conditions.is_empty():
            fallback = rule
            continue
        if _conditions_match(conditions, ending_choice):
            final_ending = str(rule.get("id","last_spark"))
            if not discovered_endings.has(final_ending):
                discovered_endings.append(final_ending)
            save()
            return rule

    if fallback.is_empty():
        fallback = {"id":"last_spark","title":"Последняя Искра","text":"Ты победил Нигила, но мир ещё должен научиться жить после вечных сумерек."}
    final_ending = str(fallback.get("id","last_spark"))
    if not discovered_endings.has(final_ending):
        discovered_endings.append(final_ending)
    save()
    return fallback

func get_final_ending() -> Dictionary:
    if final_ending != "":
        for e in story.get("ending_rules", []):
            if e.get("id","") == final_ending:
                return e
    return {}
