extends MarginContainer
class_name SafeArea

@export var base_margin := 16
@export var extra_bottom := 8

func _ready() -> void:
    _apply()

func _notification(what: int) -> void:
    if what == NOTIFICATION_RESIZED:
        _apply()

func _apply() -> void:
    var size := get_viewport_rect().size
    var scale_factor := clamp(size.x / 1280.0, 0.75, 1.35)
    var m := int(round(base_margin * scale_factor))
    var bottom := int(round((base_margin + extra_bottom) * scale_factor))
    var safe := DisplayServer.get_display_safe_area()
    var viewport_size := DisplayServer.window_get_size()
    if safe.size.x > 0 and safe.size.y > 0:
        add_theme_constant_override("margin_left", max(m, safe.position.x))
        add_theme_constant_override("margin_top", max(m, safe.position.y))
        add_theme_constant_override("margin_right", max(m, viewport_size.x - safe.end.x))
        add_theme_constant_override("margin_bottom", max(bottom, viewport_size.y - safe.end.y))
    else:
        add_theme_constant_override("margin_left", m)
        add_theme_constant_override("margin_top", m)
        add_theme_constant_override("margin_right", m)
        add_theme_constant_override("margin_bottom", bottom)
