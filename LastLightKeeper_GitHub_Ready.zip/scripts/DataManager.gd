extends Node
## Центральный read-only источник JSON-данных.

const DATA_FILES := {
	"enemies": "res://data/enemies.json",
	"items": "res://data/items.json",
	"recipes": "res://data/recipes.json",
	"quests": "res://data/quests.json",
	"achievements": "res://data/achievements.json",
	"lore_books": "res://data/lore_books.json"
}

var data: Dictionary = {}

func _ready() -> void:
	for key in DATA_FILES:
		data[key] = _load_json(DATA_FILES[key])

func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("DataManager: file not found: %s" % path)
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_error("DataManager: cannot open: %s" % path)
		return {}
	var json := JSON.new()
	var err := json.parse(file.get_as_text())
	if err != OK:
		push_error("DataManager: invalid JSON %s: %s" % [path, json.get_error_message()])
		return {}
	if not (json.data is Dictionary):
		push_error("DataManager: root must be an object: %s" % path)
		return {}
	return json.data

func get_entry(category: String, id: String) -> Dictionary:
	var category_data: Dictionary = data.get(category, {})
	var value = category_data.get(id, {})
	return value if value is Dictionary else {}

func get_category(category: String) -> Dictionary:
	return data.get(category, {})
