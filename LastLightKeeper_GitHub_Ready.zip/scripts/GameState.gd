extends Node
## Persistent player profile. Stored in user:// and migrated by schema version.

const SAVE_PATH := "user://savegame.json"
const BACKUP_PATH := "user://savegame.backup.json"
const TEMP_PATH := "user://savegame.tmp.json"
const SAVE_VERSION := 3

var inventory: Dictionary = {}
var flags: Dictionary = {}
var gold: int = 25
var experience: int = 0
var level: int = 1
var current_zone: String = "solferino"
var unlocked_zones: Array[String] = ["solferino"]
var defeated_bosses: Array[String] = []
var crafted_items: Dictionary = {}
var unlocked_recipes: Array[String] = ["light_potion", "sunsteel_blade", "shadow_ward"]
var player_max_health: float = 100.0
var player_damage: float = 18.0
var player_light_max: float = 100.0
var story: Dictionary = {}
var control_settings: Dictionary = {
	"control_mode": "virtual_joystick",
	"joystick_sensitivity": 1.0,
	"joystick_size": 150.0,
	"touch_buttons_scale": 1.0,
	"haptic_enabled": true,
	"left_handed": false
}

signal changed
signal save_completed

func _ready() -> void:
	load_game()

func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH) or FileAccess.file_exists(BACKUP_PATH)

func start_new_game() -> void:
	_reset_to_defaults()
	save_game()
	changed.emit()

func add_item(item_id: String, amount: int = 1) -> void:
	if amount <= 0:
		return
	inventory[item_id] = int(inventory.get(item_id, 0)) + amount
	save_game()
	changed.emit()

func has_item(item_id: String, amount: int = 1) -> bool:
	return int(inventory.get(item_id, 0)) >= amount

func remove_item(item_id: String, amount: int = 1) -> bool:
	if not has_item(item_id, amount):
		return false
	inventory[item_id] = int(inventory[item_id]) - amount
	if inventory[item_id] <= 0:
		inventory.erase(item_id)
	save_game()
	changed.emit()
	return true

func set_flag(flag_id: String, value: bool = true) -> void:
	flags[flag_id] = value
	save_game()
	changed.emit()

func has_flag(flag_id: String) -> bool:
	return bool(flags.get(flag_id, false))

func add_experience(amount: int) -> void:
	experience += max(amount, 0)
	var target := level * 100
	while experience >= target:
		experience -= target
		level += 1
		player_max_health += 12.0
		player_damage += 2.0
		player_light_max += 8.0
		target = level * 100
	save_game()
	changed.emit()

func add_gold(amount: int) -> void:
	gold += amount
	save_game()
	changed.emit()

func unlock_zone(zone_id: String) -> void:
	if not unlocked_zones.has(zone_id):
		unlocked_zones.append(zone_id)
		save_game()
		changed.emit()

func is_zone_unlocked(zone_id: String) -> bool:
	return unlocked_zones.has(zone_id)

func mark_boss_defeated(boss_id: String) -> void:
	if not defeated_bosses.has(boss_id):
		defeated_bosses.append(boss_id)
	flags[boss_id + "_defeated"] = true
	save_game()
	changed.emit()

func is_boss_defeated(boss_id: String) -> bool:
	return defeated_bosses.has(boss_id)

func unlock_recipe(recipe_id: String) -> void:
	if not unlocked_recipes.has(recipe_id):
		unlocked_recipes.append(recipe_id)
		save_game()
		changed.emit()

func is_recipe_unlocked(recipe_id: String) -> bool:
	return unlocked_recipes.has(recipe_id)

func set_control_setting(key: String, value: Variant) -> void:
	if not control_settings.has(key):
		return
	control_settings[key] = value
	save_game()
	changed.emit()

func get_control_setting(key: String, fallback: Variant) -> Variant:
	return control_settings.get(key, fallback)

func craft(recipe_id: String, ingredients: Dictionary, result_id: String, amount: int = 1) -> bool:
	if not is_recipe_unlocked(recipe_id):
		return false
	for item_id in ingredients:
		if not has_item(item_id, int(ingredients[item_id])):
			return false
	for item_id in ingredients:
		inventory[item_id] = int(inventory[item_id]) - int(ingredients[item_id])
		if inventory[item_id] <= 0:
			inventory.erase(item_id)
	inventory[result_id] = int(inventory.get(result_id, 0)) + amount
	crafted_items[recipe_id] = int(crafted_items.get(recipe_id, 0)) + 1
	save_game()
	changed.emit()
	return true

func save_game() -> void:
	var payload := _build_save_payload()
	var temp := FileAccess.open(TEMP_PATH, FileAccess.WRITE)
	if temp == null:
		push_error("GameState: cannot open temporary save file")
		return
	temp.store_string(JSON.stringify(payload))
	temp.flush()
	temp.close()
	if FileAccess.file_exists(SAVE_PATH):
		if FileAccess.file_exists(BACKUP_PATH):
			DirAccess.remove_absolute(BACKUP_PATH)
		DirAccess.rename_absolute(SAVE_PATH, BACKUP_PATH)
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(SAVE_PATH)
	DirAccess.rename_absolute(TEMP_PATH, SAVE_PATH)
	save_completed.emit()

func load_game() -> void:
	var payload := _read_save(SAVE_PATH)
	if payload.is_empty():
		payload = _read_save(BACKUP_PATH)
	if payload.is_empty():
		_reset_to_defaults()
		return
	_apply_save(payload)

func _read_save(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}
	var json := JSON.new()
	if json.parse(file.get_as_text()) != OK or not (json.data is Dictionary):
		return {}
	return json.data

func _build_save_payload() -> Dictionary:
	return {
		"save_version": SAVE_VERSION,
		"saved_at_unix": Time.get_unix_time_from_system(),
		"inventory": inventory.duplicate(true),
		"flags": flags.duplicate(true),
		"gold": gold,
		"experience": experience,
		"level": level,
		"current_zone": current_zone,
		"unlocked_zones": unlocked_zones.duplicate(),
		"defeated_bosses": defeated_bosses.duplicate(),
		"crafted_items": crafted_items.duplicate(true),
		"unlocked_recipes": unlocked_recipes.duplicate(),
		"player_max_health": player_max_health,
		"player_damage": player_damage,
		"player_light_max": player_light_max,
		"control_settings": control_settings.duplicate(true),
		"story": story.duplicate(true)
	}

func _apply_save(p: Dictionary) -> void:
	var version := int(p.get("save_version", 1))
	inventory = _dict(p.get("inventory", {"light_shard": 2, "herb": 1}))
	flags = _dict(p.get("flags", {}))
	gold = int(p.get("gold", 25))
	experience = int(p.get("experience", 0))
	level = max(1, int(p.get("level", 1)))
	current_zone = str(p.get("current_zone", "solferino"))
	unlocked_zones = _string_array(p.get("unlocked_zones", ["solferino"]))
	if unlocked_zones.is_empty(): unlocked_zones = ["solferino"]
	defeated_bosses = _string_array(p.get("defeated_bosses", []))
	crafted_items = _dict(p.get("crafted_items", {}))
	unlocked_recipes = _string_array(p.get("unlocked_recipes", ["light_potion", "sunsteel_blade", "shadow_ward"]))
	if unlocked_recipes.is_empty(): unlocked_recipes = ["light_potion", "sunsteel_blade", "shadow_ward"]
	player_max_health = float(p.get("player_max_health", 100.0))
	player_damage = float(p.get("player_damage", 18.0))
	player_light_max = float(p.get("player_light_max", 100.0))
	control_settings = _merge_control_settings(_dict(p.get("control_settings", {})))
	story = _dict(p.get("story", {}))
	if version < SAVE_VERSION:
		save_game()

func _reset_to_defaults() -> void:
	inventory = {"light_shard": 2, "herb": 1}
	flags = {}
	gold = 25
	experience = 0
	level = 1
	current_zone = "solferino"
	unlocked_zones = ["solferino"]
	defeated_bosses = []
	crafted_items = {}
	unlocked_recipes = ["light_potion", "sunsteel_blade", "shadow_ward"]
	player_max_health = 100.0
	player_damage = 18.0
	player_light_max = 100.0
	control_settings = _merge_control_settings({})
	story = {}

func _dict(value: Variant) -> Dictionary:
	return value.duplicate(true) if value is Dictionary else {}

func _string_array(value: Variant) -> Array[String]:
	var result: Array[String] = []
	if value is Array:
		for item in value: result.append(str(item))
	return result

func _merge_control_settings(saved: Dictionary) -> Dictionary:
	var defaults := {"control_mode":"virtual_joystick","joystick_sensitivity":1.0,"joystick_size":150.0,"touch_buttons_scale":1.0,"haptic_enabled":true,"left_handed":false}
	for key in saved:
		if defaults.has(key): defaults[key] = saved[key]
	defaults.joystick_sensitivity = clamp(float(defaults.joystick_sensitivity), 0.5, 2.0)
	defaults.joystick_size = clamp(float(defaults.joystick_size), 120.0, 210.0)
	defaults.touch_buttons_scale = clamp(float(defaults.touch_buttons_scale), 0.8, 1.3)
	defaults.haptic_enabled = bool(defaults.haptic_enabled)
	defaults.left_handed = bool(defaults.left_handed)
	return defaults
