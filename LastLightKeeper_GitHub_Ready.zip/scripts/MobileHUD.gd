extends CanvasLayer
class_name MobileHUD

@export var reference_width := 1280.0
@export var reference_height := 720.0

func _ready() -> void:
    get_viewport().size_changed.connect(_rescale)
    _rescale()

func _rescale() -> void:
    var size := get_viewport().get_visible_rect().size
    var scale_factor := clamp(min(size.x / reference_width, size.y / reference_height), 0.72, 1.25)
    for node in get_tree().get_nodes_in_group("mobile_button"):
        if node is Control:
            var px := clamp(96.0 * scale_factor, 64.0, 112.0)
            node.custom_minimum_size = Vector2(px, px)
    for node in get_tree().get_nodes_in_group("mobile_text"):
        if node is Label:
            node.add_theme_font_size_override("font_size", int(clamp(22.0 * scale_factor, 16.0, 28.0)))
