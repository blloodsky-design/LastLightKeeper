extends Node

var menu: Control
var game: GameController

func _ready() -> void:
	_show_main_menu()

func _show_main_menu() -> void:
	if game:
		game.queue_free()
		game = null
	if menu:
		menu.queue_free()
	menu = Control.new()
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(menu)
	menu.set_script(load("res://ui/MainMenu.gd"))
	menu.start_requested.connect(_start_new_game)
	menu.continue_requested.connect(_continue_game)
	menu.settings_requested.connect(_open_settings)
	menu.exit_requested.connect(_exit_game)
	menu.call_deferred("refresh")

func _start_new_game() -> void:
	GameState.start_new_game()
	StoryManager.reset_for_new_game()
	_start_game()

func _continue_game() -> void:
	_start_game()

func _start_game() -> void:
	if menu:
		menu.queue_free()
		menu = null
	game = GameController.new()
	add_child(game)
	game.finished.connect(_on_game_finished)

func _on_game_finished() -> void:
	_show_main_menu()

func _open_settings() -> void:
	# Main-menu settings use the same persistent values as the in-game settings.
	var screen := Control.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(screen)
	screen.set_script(load("res://ui/MainSettings.gd"))
	screen.back_requested.connect(func(): screen.queue_free())
	screen.call_deferred("refresh")

func _exit_game() -> void:
	GameState.save_game()
	get_tree().quit()
