extends Control
class_name EndingResultScreen

@onready var title_label: Label = $Panel/VBox/Title
@onready var description_label: Label = $Panel/VBox/Description
@onready var conditions_label: Label = $Panel/VBox/Conditions
@onready var stats_label: Label = $Panel/VBox/Stats
@onready var completion_label: Label = $Panel/VBox/Completion
@onready var progress_label: Label = $Panel/VBox/Progress
@onready var achievements_label: Label = $Panel/VBox/Achievements

const TOTAL_BOSSES := 5
const TOTAL_BIOMES := 5
const TOTAL_QUESTS := 5
const TOTAL_NPCS := 4
const TOTAL_LORE := 6
const TOTAL_ENDINGS := 5

func _ready() -> void:
    show_result()

func _pct(done: int, total: int) -> int:
    if total <= 0:
        return 0
    return int(round(100.0 * float(min(done, total)) / float(total)))

func _achievement_unlocked(id: String) -> bool:
    var bosses := GameState.defeated_bosses
    var zones := GameState.unlocked_zones
    var quests := StoryManager.completed_quests
    var rescued := StoryManager.get_rescued_count()
    var lore := StoryManager.discovered_lore.size()
    var decisions := StoryManager.decisions.size()
    var endings := StoryManager.discovered_endings.size()

    if id == "first_blood":
        return StatsManager.has_action("first_blood") or bosses.size() > 0 or quests.size() > 0
    if id == "forge_slayer":
        return bosses.has("forge_guardian") or bosses.has("Страж Горнила Судеб")
    if id == "forest_slayer":
        return bosses.has("forest_mother") or bosses.has("Матерь Корней")
    if id == "crystal_hunter":
        return bosses.has("crystal_scorpion") or bosses.has("Кристаллический Скорпион")
    if id == "tidebreaker":
        return bosses.has("tide_colossus") or bosses.has("Колосс Прилива")
    if id == "last_sun":
        return bosses.has("nigil") or bosses.has("Нигил — Чёрное Солнце")
    if id == "lorekeeper":
        return lore >= TOTAL_LORE
    if id == "rescuer":
        return rescued >= TOTAL_NPCS
    if id == "master_crafter":
        return GameState.crafted_items.size() >= 3
    if id == "many_paths":
        return decisions >= 4
    if id == "all_endings":
        return endings >= TOTAL_ENDINGS
    return bool(StatsManager.has_action("achievement_" + id))

func _load_achievements() -> Array:
    if not FileAccess.file_exists("res://data/completion_achievements.json"):
        return []
    var file := FileAccess.open("res://data/completion_achievements.json", FileAccess.READ)
    if file == null:
        return []
    var parsed = JSON.parse_string(file.get_as_text())
    return parsed if parsed is Array else []

func _build_achievements() -> void:
    var list := _load_achievements()
    var unlocked := 0
    var lines: Array[String] = ["ДОСТИЖЕНИЯ"]

    for a in list:
        var id := str(a.get("id",""))
        var is_open := _achievement_unlocked(id)
        if is_open:
            unlocked += 1
        var mark := "✓ ОТКРЫТО" if is_open else "○ НЕ ОТКРЫТО"
        lines.append("")
        lines.append("%s  —  %s" % [str(a.get("title","")), mark])
        lines.append(str(a.get("description","")))

    var total := list.size()
    var percent := _pct(unlocked, total)
    lines.insert(1, "Открыто: %d/%d  •  %d%%" % [unlocked, total, percent])
    achievements_label.text = "\n".join(lines)

func show_result() -> void:
    var ending := StoryManager.evaluate_ending()
    title_label.text = str(ending.get("title","Последняя Искра"))
    description_label.text = str(ending.get("text",""))
    conditions_label.text = "Условия открытия:\n" + str(ending.get("unlock_conditions_text","Особые условия."))

    var bosses := int(GameState.defeated_bosses.size())
    var biomes := int(GameState.unlocked_zones.size())
    var quests := StoryManager.completed_quests.size()
    var npcs := StoryManager.get_rescued_count()
    var lore := StoryManager.discovered_lore.size()
    var endings := StoryManager.discovered_endings.size()

    var categories := [
        _pct(bosses, TOTAL_BOSSES),
        _pct(biomes, TOTAL_BIOMES),
        _pct(quests, TOTAL_QUESTS),
        _pct(npcs, TOTAL_NPCS),
        _pct(lore, TOTAL_LORE),
        _pct(endings, TOTAL_ENDINGS)
    ]
    var overall := int(round((categories[0] + categories[1] + categories[2] + categories[3] + categories[4] + categories[5]) / 6.0))

    completion_label.text = "ОБЩЕЕ ЗАВЕРШЕНИЕ ИГРЫ: %d%%" % overall
    progress_label.text = \
        "Боссы        %d%%   (%d/%d)\n" % [categories[0], bosses, TOTAL_BOSSES] + \
        "Биомы        %d%%   (%d/%d)\n" % [categories[1], biomes, TOTAL_BIOMES] + \
        "Квесты       %d%%   (%d/%d)\n" % [categories[2], quests, TOTAL_QUESTS] + \
        "NPC          %d%%   (%d/%d)\n" % [categories[3], npcs, TOTAL_NPCS] + \
        "Лор          %d%%   (%d/%d)\n" % [categories[4], lore, TOTAL_LORE] + \
        "Концовки     %d%%   (%d/%d)" % [categories[5], endings, TOTAL_ENDINGS]

    var level := int(GameState.level)
    var xp := int(GameState.experience)
    stats_label.text = "СТАТИСТИКА ПРОХОЖДЕНИЯ\n\n" + \
        "Уровень: %d\nОпыт: %d\nПринятых решений: %d\n\nПолученная концовка: %s" % \
        [level, xp, StoryManager.decisions.size(), str(ending.get("title",""))]

    _build_achievements()

func _on_continue_pressed() -> void:
    get_tree().change_scene_to_file("res://scenes/Main.tscn")
