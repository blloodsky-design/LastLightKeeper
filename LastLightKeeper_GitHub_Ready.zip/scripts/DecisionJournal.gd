extends Control
## Simple persistent decisions/quest consequences journal.
@onready var list_label: Label = $Panel/VBox/List

func refresh() -> void:
    var lines: Array[String] = []
    for key in StoryManager.decisions:
        var value = StoryManager.decisions[key]
        lines.append("%s: %s" % [key, str(value)])
    if lines.is_empty():
        list_label.text = "Решений пока нет."
    else:
        list_label.text = "\n".join(lines)
