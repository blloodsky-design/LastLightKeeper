extends Node
class_name AndroidInput

## Простая виртуальная ось для мобильного управления.
## UI-кнопки вызывают set_axis(), а Player читает get_axis().

var axis := Vector2.ZERO

func set_axis(direction: Vector2) -> void:
	axis = direction.limit_length(1.0)

func get_axis() -> Vector2:
	return axis
