extends Control
class_name BranchingDialogue
## Displays one dialogue node and persists the player's selected consequence.

@onready var speaker_label: Label = $Panel/VBox/Speaker
@onready var text_label: Label = $Panel/VBox/Text
@onready var choices_box: VBoxContainer = $Panel/VBox/Choices

var dialogue_id := ""
var on_finished: Callable

func start(id: String, finished: Callable = Callable()) -> void:
    dialogue_id = id
    on_finished = finished
    var data := StoryManager.get_branching_dialogue(id)
    if data.is_empty():
        _finish()
        return

    visible = true
    speaker_label.text = str(data.get("speaker",""))
    text_label.text = str(data.get("text",""))

    for child in choices_box.get_children():
        child.queue_free()

    for choice in data.get("choices", []):
        var button := Button.new()
        button.text = str(choice.get("text",""))
        button.custom_minimum_size = Vector2(0, 64)
        button.pressed.connect(func(): _choose(choice))
        choices_box.add_child(button)

func _choose(choice: Dictionary) -> void:
    StoryManager.record_decision(
        dialogue_id,
        str(choice.get("id","")),
        Dictionary(choice.get("set", {})),
        Dictionary(choice.get("quest_effect", {}))
    )

    var reward: Dictionary = Dictionary(choice.get("reward", {}))
    if not reward.is_empty() and reward.has("item"):
        GameState.add_item(str(reward["item"]), int(reward.get("count", 1)))
        GameState.save_game()

    _finish()

func _finish() -> void:
    visible = false
    if on_finished.is_valid():
        on_finished.call()
