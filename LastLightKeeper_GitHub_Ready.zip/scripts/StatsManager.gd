extends Node
## Достижения и одноразовые игровые действия.

const SAVE_PATH := "user://stats.json"
var actions: Dictionary = {}

func _ready() -> void:
	_load()

func register_action(action_id: String) -> void:
	if actions.get(action_id, false):
		return
	actions[action_id] = true
	_save()

func has_action(action_id: String) -> bool:
	return bool(actions.get(action_id, false))

func _save() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"actions": actions}))

func _load() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var json := JSON.new()
	if json.parse(file.get_as_text()) == OK and json.data is Dictionary:
		actions = json.data.get("actions", {})
