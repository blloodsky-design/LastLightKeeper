# Full game flow

1. `Main.tscn` starts `Main.gd` and shows the main menu.
2. `Новая игра` resets the profile and enters the current starting zone: Solferino.
3. `Продолжить` loads `GameState.current_zone` and all persistent progress.
4. The HUD exposes map, inventory, crafting and control settings.
5. The world map unlocks zones in this order:
   Solferino -> Whispering Forest -> Glass Wastes -> Sunken Archipelago -> Void Citadel.
6. Each zone spawns its enemies and boss. Defeating the boss awards XP, gold, materials and unlocks the next zone.
7. The Void Citadel boss `nigil` sets `eternal_twilight_ended` and opens the final scene.
8. The final scene can return to the main menu without deleting the completed save.
9. Save data is stored by `GameState` in `user://savegame.json` with a backup and version migration.
