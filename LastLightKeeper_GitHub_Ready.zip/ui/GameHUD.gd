extends CanvasLayer
class_name GameHUD

const WorldMapView = preload("res://ui/WorldMap.gd")

var game: GameController
var safe: Control
var top: HBoxContainer
var hp_bar: ProgressBar
var light_bar: ProgressBar
var title_label: Label
var overlay: PanelContainer
var content: VBoxContainer
var joystick: VirtualJoystick
var action_container: VBoxContainer
var attack_button: Button
var interact_button: Button
var settings_button: Button

func _ready() -> void:
	layer = 20
	safe = Control.new()
	safe.set_script(load("res://ui/SafeArea.gd"))
	add_child(safe)
	_build_hud()
	_build_overlay()

func bind_game(g: GameController) -> void:
	game = g

func _build_hud() -> void:
	var root := MarginContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("margin_left", 24)
	root.add_theme_constant_override("margin_right", 24)
	root.add_theme_constant_override("margin_top", 18)
	root.add_theme_constant_override("margin_bottom", 18)
	safe.add_child(root)
	var layer_box := Control.new()
	root.add_child(layer_box)
	top = HBoxContainer.new()
	top.position = Vector2(10,10)
	top.add_theme_constant_override("separation", 14)
	layer_box.add_child(top)
	title_label = Label.new()
	title_label.text = "Хранитель Света"
	title_label.add_theme_font_size_override("font_size", 24)
	top.add_child(title_label)
	hp_bar = _bar()
	light_bar = _bar()
	top.add_child(hp_bar)
	top.add_child(light_bar)
	var map_button := _button("КАРТА", 120)
	map_button.pressed.connect(func(): game.open_world_map())
	top.add_child(map_button)
	var inv_button := _button("СУМКА", 120)
	inv_button.pressed.connect(func(): game.open_inventory())
	top.add_child(inv_button)
	var craft_button := _button("КРАФТ", 120)
	craft_button.pressed.connect(func(): game.open_crafting())
	top.add_child(craft_button)
	var story_button := _button("ИСТОРИЯ", 125)
	story_button.pressed.connect(func(): show_story(game))
	top.add_child(story_button)
	settings_button = _button("⚙", 70)
	settings_button.pressed.connect(func(): game.open_settings())
	top.add_child(settings_button)

	joystick = VirtualJoystick.new()
	joystick.position = Vector2(45, 0)
	joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	joystick.position.y = -190
	joystick.position.x = 35
	joystick.custom_minimum_size = Vector2(150,150)
	layer_box.add_child(joystick)
	action_container = VBoxContainer.new()
	action_container.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	action_container.position = Vector2(-190,-220)
	action_container.add_theme_constant_override("separation", 12)
	layer_box.add_child(action_container)
	attack_button = Button.new()
	attack_button.text = "СВЕТ"
	attack_button.custom_minimum_size = Vector2(145,70)
	attack_button.pressed.connect(func(): _attack())
	action_container.add_child(attack_button)
	interact_button = Button.new()
	interact_button.text = "ИСТОРИЯ"
	interact_button.custom_minimum_size = Vector2(145,58)
	interact_button.pressed.connect(func(): show_story(game))
	action_container.add_child(interact_button)
	_apply_control_settings()

func _build_overlay() -> void:
	overlay = PanelContainer.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.visible = false
	safe.add_child(overlay)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 60)
	margin.add_theme_constant_override("margin_right", 60)
	margin.add_theme_constant_override("margin_top", 50)
	margin.add_theme_constant_override("margin_bottom", 50)
	overlay.add_child(margin)
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 14)
	margin.add_child(content)

func _bar() -> ProgressBar:
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(190,28)
	bar.max_value = 100
	bar.value = 100
	return bar

func _button(text_value: String, width: float) -> Button:
	var b := Button.new()
	b.text = text_value
	b.custom_minimum_size = Vector2(width,52)
	return b

func _clear_content() -> void:
	for child in content.get_children():
		child.queue_free()

func _title(text_value: String) -> Label:
	var l := Label.new()
	l.text = text_value
	l.add_theme_font_size_override("font_size", 30)
	return l

func show_zone(z: GameZone) -> void:
	overlay.visible = false
	title_label.text = z.zone_title
	await get_tree().process_frame
	var p := z.player
	if p:
		p.health_changed.connect(_set_hp)
		p.light_changed.connect(_set_light)
		_set_hp(p.health,p.max_health)
		_set_light(p.light_energy,p.max_light)

func _set_hp(v: float, m: float) -> void:
	if hp_bar:
		hp_bar.max_value = m
		hp_bar.value = v
		hp_bar.tooltip_text = "Здоровье %.0f / %.0f" % [v,m]

func _set_light(v: float, m: float) -> void:
	if light_bar:
		light_bar.max_value = m
		light_bar.value = v
		light_bar.tooltip_text = "Свет %.0f / %.0f" % [v,m]

func _attack() -> void:
	var p := get_tree().get_first_node_in_group("player") as Player
	if p:
		p.light_attack()

func show_world_map(g: GameController) -> void:
	overlay.visible = true
	_clear_content()
	content.add_child(_title("Ожерелье Света"))
	var map := WorldMapView.new()
	map.custom_minimum_size = Vector2(0, 360)
	map.size_flags_vertical = Control.SIZE_EXPAND_FILL
	map.zone_selected.connect(func(zone_id: String): g.load_zone(zone_id))
	content.add_child(map)
	var desc := Label.new()
	desc.text = "Побеждай хранителей. Золотая нить открывает следующий остров."
	content.add_child(desc)
	var zones := [
		["solferino","Долина Сольферино","Страж Горнила Судеб"],
		["whispering_forest","Шепчущий Лес","Матерь Корней"],
		["glass_wastes","Стеклянные Пустоши","Кристаллический Скорпион"],
		["sunken_archipelago","Затонувший Архипелаг","Колосс Прилива"],
		["void_citadel","Цитадель Пустоты","Нигил — Чёрное Солнце"]
	]
	for z in zones:
		var b := Button.new()
		var unlocked := GameState.is_zone_unlocked(z[0])
		var defeated := GameState.is_boss_defeated(_boss_for(z[0]))
		b.text = ("✓ " if defeated else "○ ") + z[1] + (" — открыто" if unlocked else " — закрыто")
		b.disabled = not unlocked
		b.custom_minimum_size = Vector2(0,58)
		b.pressed.connect(func(zone_id: String = z[0]): g.load_zone(zone_id))
		content.add_child(b)
	var back := _button("НАЗАД", 180)
	back.pressed.connect(func(): show_zone(game.zone))
	content.add_child(back)

func _boss_for(zone_id: String) -> String:
	return {"solferino":"forge_guardian","whispering_forest":"root_mother","glass_wastes":"crystal_scorpion","sunken_archipelago":"tide_colossus","void_citadel":"nigil"}.get(zone_id,"")

func show_inventory(g: GameController) -> void:
	overlay.visible = true
	_clear_content()
	content.add_child(_title("Инвентарь"))
	var stats := Label.new()
	stats.text = "Уровень %d   Опыт %d   Золото %d\nУрон %.0f   Макс. HP %.0f   Макс. Свет %.0f" % [GameState.level,GameState.experience,GameState.gold,GameState.player_damage,GameState.player_max_health,GameState.player_light_max]
	content.add_child(stats)
	for id in GameState.inventory:
		var row := HBoxContainer.new()
		var item := Label.new()
		item.text = "%s  × %d" % [_item_name(str(id)), int(GameState.inventory[id])]
		item.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(item)
		if str(id) == "light_potion":
			var use := Button.new()
			use.text = "ИСПОЛЬЗОВАТЬ"
			use.pressed.connect(func(): _use_potion())
			row.add_child(use)
		content.add_child(row)
	if GameState.inventory.is_empty():
		var empty := Label.new()
		empty.text = "Пока пусто. Исследуй биомы и побеждай врагов."
		content.add_child(empty)
	var back := _button("НАЗАД",180)
	back.pressed.connect(func(): show_zone(game.zone))
	content.add_child(back)

func show_settings(g: GameController) -> void:
	overlay.visible = true
	_clear_content()
	content.add_child(_title("Настройки управления"))
	var info := Label.new()
	info.text = "Настройки сохраняются автоматически и применяются сразу."
	content.add_child(info)

	var sens_label := Label.new()
	sens_label.text = "Чувствительность джойстика: %.1fx" % float(GameState.get_control_setting("joystick_sensitivity", 1.0))
	content.add_child(sens_label)
	var sens := HSlider.new()
	sens.min_value = 0.5
	sens.max_value = 2.0
	sens.step = 0.05
	sens.value = float(GameState.get_control_setting("joystick_sensitivity", 1.0))
	sens.custom_minimum_size = Vector2(0, 44)
	sens.value_changed.connect(func(v: float):
		GameState.set_control_setting("joystick_sensitivity", v)
		sens_label.text = "Чувствительность джойстика: %.1fx" % v
		_apply_control_settings()
	)
	content.add_child(sens)

	var size_label := Label.new()
	size_label.text = "Размер джойстика: %.0f" % float(GameState.get_control_setting("joystick_size", 150.0))
	content.add_child(size_label)
	var size_slider := HSlider.new()
	size_slider.min_value = 120.0
	size_slider.max_value = 210.0
	size_slider.step = 5.0
	size_slider.value = float(GameState.get_control_setting("joystick_size", 150.0))
	size_slider.custom_minimum_size = Vector2(0, 44)
	size_slider.value_changed.connect(func(v: float):
		GameState.set_control_setting("joystick_size", v)
		size_label.text = "Размер джойстика: %.0f" % v
		_apply_control_settings()
	)
	content.add_child(size_slider)

	var button_label := Label.new()
	button_label.text = "Размер сенсорных кнопок: %.0fx" % float(GameState.get_control_setting("touch_buttons_scale", 1.0))
	content.add_child(button_label)
	var button_slider := HSlider.new()
	button_slider.min_value = 0.8
	button_slider.max_value = 1.3
	button_slider.step = 0.05
	button_slider.value = float(GameState.get_control_setting("touch_buttons_scale", 1.0))
	button_slider.custom_minimum_size = Vector2(0, 44)
	button_slider.value_changed.connect(func(v: float):
		GameState.set_control_setting("touch_buttons_scale", v)
		button_label.text = "Размер сенсорных кнопок: %.0fx" % v
		_apply_control_settings()
	)
	content.add_child(button_slider)

	var haptic := CheckButton.new()
	haptic.text = "Вибрация при управлении"
	haptic.button_pressed = bool(GameState.get_control_setting("haptic_enabled", true))
	haptic.toggled.connect(func(v: bool): GameState.set_control_setting("haptic_enabled", v))
	content.add_child(haptic)

	var handed := CheckButton.new()
	handed.text = "Леворукий режим"
	handed.button_pressed = bool(GameState.get_control_setting("left_handed", false))
	handed.toggled.connect(func(v: bool):
		GameState.set_control_setting("left_handed", v)
		_apply_control_settings()
	)
	content.add_child(handed)

	var back := _button("НАЗАД",180)
	back.pressed.connect(func(): show_zone(game.zone))
	content.add_child(back)

func _apply_control_settings() -> void:
	if joystick:
		joystick.apply_saved_settings()
	var scale_value := float(GameState.get_control_setting("touch_buttons_scale", 1.0))
	if attack_button:
		attack_button.scale = Vector2.ONE * scale_value
	if interact_button:
		interact_button.scale = Vector2.ONE * scale_value
	var left_handed := bool(GameState.get_control_setting("left_handed", false))
	if action_container:
		if left_handed:
			action_container.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
			action_container.position = Vector2(35,-220)
		else:
			action_container.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
			action_container.position = Vector2(-190,-220)

func show_story(g: GameController) -> void:
	overlay.visible = true
	_clear_content()
	content.add_child(_title("История и решения"))
	var info := Label.new()
	info.text = "Квесты, спасённые NPC, лор и решения сохраняются между загрузками."
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(info)
	var progress := Label.new()
	progress.text = "Квесты: %d/5   NPC: %d/4   Лор: %d/6   Решения: %d" % [StoryManager.completed_quests.size(), StoryManager.get_rescued_count(), StoryManager.discovered_lore.size(), StoryManager.decisions.size()]
	content.add_child(progress)
	var npc_title := Label.new(); npc_title.text = "NPC текущего биома"; content.add_child(npc_title)
	for npc in StoryManager.get_npcs_for_zone(GameState.current_zone):
		var id := str(npc.get("id", ""))
		var b := _button(("✓ " if StoryManager.rescued_npcs.has(id) else "СПАСТИ: ") + str(npc.get("name", id)), 520)
		b.disabled = StoryManager.rescued_npcs.has(id)
		b.pressed.connect(func(npc_id: String = id): StoryManager.rescue_npc(npc_id); show_story(game))
		content.add_child(b)
	var choice_title := Label.new(); choice_title.text = "Решения текущего биома"; content.add_child(choice_title)
	for dialogue in StoryManager.story.get("branching_dialogues", []):
		if str(dialogue.get("zone", "")) != GameState.current_zone:
			continue
		var dialogue_id := str(dialogue.get("id", ""))
		var dtext := Label.new(); dtext.text = str(dialogue.get("speaker", "")) + ": " + str(dialogue.get("text", "")); dtext.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; content.add_child(dtext)
		for choice in dialogue.get("choices", []):
			var cb := _button(str(choice.get("text", "")), 650)
			cb.disabled = StoryManager.get_decision(dialogue_id) != ""
			cb.pressed.connect(func(did: String = dialogue_id, c: Dictionary = choice):
				StoryManager.record_decision(did, str(c.get("id", "")), Dictionary(c.get("set", {})), Dictionary(c.get("quest_effect", {})))
				var reward: Dictionary = Dictionary(c.get("reward", {}))
				if reward.has("item"): GameState.add_item(str(reward.get("item", "")), int(reward.get("count", 1)))
				show_story(game))
			content.add_child(cb)
	var lore_title := Label.new(); lore_title.text = "Лор"; content.add_child(lore_title)
	for lore in StoryManager.story.get("lore", []):
		var lore_id_text := str(lore.get("id", ""))
		if lore_id_text == "lore_necklace" or lore_id_text.find(_lore_key_for_zone(GameState.current_zone)) >= 0:
			var lid := lore_id_text
			var lb := _button(("✓ " if StoryManager.discovered_lore.has(lid) else "ОТКРЫТЬ: ") + str(lore.get("title", lid)), 520)
			lb.disabled = StoryManager.discovered_lore.has(lid)
			lb.pressed.connect(func(lore_id: String = lid): StoryManager.discover_lore(lore_id); show_story(game))
			content.add_child(lb)
	var back := _button("НАЗАД", 180)
	back.pressed.connect(func(): show_zone(game.zone))
	content.add_child(back)

func _story_dialogue_for_zone(zone_id: String) -> String:
	return {"solferino":"oldus_first_choice", "whispering_forest":"silva_forest_choice", "void_citadel":"nigil_final_choice"}.get(zone_id, "")

func _lore_key_for_zone(zone_id: String) -> String:
	return {"solferino":"solferino", "whispering_forest":"forest", "glass_wastes":"glass", "sunken_archipelago":"archipelago", "void_citadel":"nigil"}.get(zone_id, "necklace")

func show_crafting(g: GameController) -> void:
	overlay.visible = true
	_clear_content()
	content.add_child(_title("Кузница Хранителя"))
	var recipes := [
		["light_potion","Зелье Света — 2 Осколка Света + 1 Живица"],
		["sunsteel_blade","Клинок Солнестали — 3 Осколка + 2 Древние Монеты"],
		["shadow_ward","Оберег Тени — 2 Тёмного Железа + 4 Осколка"]
	]
	for r in recipes:
		var b := _button(r[1], 500)
		b.pressed.connect(func(recipe_id: String = r[0]): g.craft_item(recipe_id))
		content.add_child(b)
	var hint := Label.new()
	hint.text = "Рецепты меняют характеристики героя и сохраняются автоматически."
	content.add_child(hint)
	var back := _button("НАЗАД",180)
	back.pressed.connect(func(): show_zone(game.zone))
	content.add_child(back)

func _use_potion() -> void:
	if not GameState.remove_item("light_potion", 1):
		return
	var p := get_tree().get_first_node_in_group("player") as Player
	if p:
		p.restore_light(35.0)
		p.take_damage(-25.0)
	show_inventory(game)

func _item_name(id: String) -> String:
	return {"light_shard":"Осколок Света","herb":"Живица Света","ancient_coin":"Древняя Монета","dark_iron":"Тёмное Железо","light_potion":"Зелье Света","sunsteel_blade":"Клинок Солнестали","shadow_ward":"Оберег Тени"}.get(id,id)

func is_overlay_open() -> bool:
	return overlay.visible
