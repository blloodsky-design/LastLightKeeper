extends Control
class_name ResponsiveUI

## Applies a conservative UI scale across phones and tablets without changing
## the logical game viewport. Children should use anchors/containers, not pixels.

@export var reference_short_side: float = 720.0
@export var min_scale: float = 0.82
@export var max_scale: float = 1.35

func _ready() -> void:
    get_viewport().size_changed.connect(_update_scale)
    _update_scale()

func _exit_tree() -> void:
    if get_viewport().size_changed.is_connected(_update_scale):
        get_viewport().size_changed.disconnect(_update_scale)

func _update_scale() -> void:
    var viewport_size := get_viewport_rect().size
    var short_side := min(viewport_size.x, viewport_size.y)
    var factor := clamp(short_side / reference_short_side, min_scale, max_scale)
    scale = Vector2.ONE * factor
