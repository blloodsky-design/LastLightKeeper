extends Control
class_name BookReader

@onready var title_label: Label = $VBoxContainer/TitleLabel
@onready var text_label: Label = $VBoxContainer/TextLabel

var pages: Array[String] = []
var current_page: int = 0

func _ready() -> void:
	visible = false

func open_book(book_id: String) -> void:
	var book := DataManager.get_entry("lore_books", book_id)
	if book.is_empty():
		push_warning("BookReader: unknown book '%s'" % book_id)
		return
	title_label.text = tr(str(book.get("title", "")))
	pages.clear()
	for page in book.get("pages", []):
		pages.append(str(page))
	current_page = 0
	_show_page()
	visible = true

func _show_page() -> void:
	text_label.text = "" if pages.is_empty() else tr(pages[current_page])

func _on_next_pressed() -> void:
	if current_page < pages.size() - 1:
		current_page += 1
		_show_page()

func _on_previous_pressed() -> void:
	if current_page > 0:
		current_page -= 1
		_show_page()

func _on_close_pressed() -> void:
	visible = false
