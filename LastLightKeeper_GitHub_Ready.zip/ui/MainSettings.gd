extends Control
class_name MainSettings
signal back_requested
var box: VBoxContainer

func refresh() -> void:
	var center := CenterContainer.new(); center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(center)
	box = VBoxContainer.new(); box.custom_minimum_size = Vector2(650,0); box.add_theme_constant_override("separation",14); center.add_child(box)
	var title := Label.new(); title.text="НАСТРОЙКИ УПРАВЛЕНИЯ"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",32); box.add_child(title)
	_add_slider("Чувствительность", "joystick_sensitivity", 0.5, 2.0, 0.05)
	_add_slider("Размер джойстика", "joystick_size", 120.0, 210.0, 5.0)
	_add_slider("Размер кнопок", "touch_buttons_scale", 0.8, 1.3, 0.05)
	_add_check("Вибрация", "haptic_enabled")
	_add_check("Леворукий режим", "left_handed")
	var back := Button.new(); back.text="НАЗАД"; back.custom_minimum_size.y=60; back.pressed.connect(func(): back_requested.emit()); box.add_child(back)

func _add_slider(label_text: String, key: String, min_v: float, max_v: float, step: float) -> void:
	var label:=Label.new(); label.text=label_text; box.add_child(label)
	var s:=HSlider.new(); s.min_value=min_v; s.max_value=max_v; s.step=step; s.value=float(GameState.get_control_setting(key,min_v)); s.custom_minimum_size.y=40
	s.value_changed.connect(func(v:float): GameState.set_control_setting(key,v))
	box.add_child(s)

func _add_check(label_text:String,key:String)->void:
	var c:=CheckButton.new(); c.text=label_text; c.button_pressed=bool(GameState.get_control_setting(key,false)); c.toggled.connect(func(v:bool): GameState.set_control_setting(key,v)); box.add_child(c)
