extends Control
class_name BossIntro

@onready var boss_title: Label = $TitleLabel

func _ready() -> void:
	visible = false
	modulate.a = 0.0

func play_boss_intro(boss_name_key: String) -> void:
	boss_title.text = tr(boss_name_key)
	visible = true
	modulate.a = 0.0
	var tween := create_tween()
	tween.tween_property(self, "modulate:a", 1.0, 0.5)
	tween.tween_interval(2.0)
	tween.tween_property(self, "modulate:a", 0.0, 0.5)
	tween.tween_callback(_finish)

func _finish() -> void:
	visible = false
