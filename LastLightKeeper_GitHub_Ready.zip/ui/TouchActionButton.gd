extends Button
class_name TouchActionButton

@export var action_name: String = "attack"

func _ready() -> void:
	focus_mode = Control.FOCUS_NONE
	mouse_filter = Control.MOUSE_FILTER_STOP
	pressed.connect(_on_pressed)

func _on_pressed() -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		return

	if action_name == "interact":
		var areas := player.get_tree().get_nodes_in_group("interactable")
		if not areas.is_empty() and areas[0].has_method("interact"):
			areas[0].interact()
	elif action_name == "attack":
		if player.has_method("light_attack"):
			player.light_attack()
