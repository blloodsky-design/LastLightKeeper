extends Control
class_name AndroidScreen

@export var title_text: String = "Last Light Keeper"
@export var subtitle_text: String = ""

func _ready() -> void:
    get_viewport().size_changed.connect(_layout)
    _layout()

func _exit_tree() -> void:
    if get_viewport().size_changed.is_connected(_layout):
        get_viewport().size_changed.disconnect(_layout)

func _layout() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
