extends Control
class_name Intro

@onready var text_label: Label = $TextLabel
var intro_lines: Array[String] = ["INTRO_LINE_1", "INTRO_LINE_2", "INTRO_LINE_3"]
var line_idx: int = 0

func _ready() -> void:
	_show_next_line()

func _show_next_line() -> void:
	if line_idx < intro_lines.size():
		text_label.text = tr(intro_lines[line_idx])
		line_idx += 1
	else:
		queue_free()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_accept"):
		_show_next_line()
