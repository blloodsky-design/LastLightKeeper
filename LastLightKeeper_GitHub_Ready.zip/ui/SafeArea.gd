extends Control
class_name AndroidSafeArea

## Universal Android safe-area container.
## Keeps UI away from display cutouts, system bars and gesture areas.
## Falls back gracefully on desktop/emulators that don't report a safe area.

@export var extra_left: float = 16.0
@export var extra_top: float = 16.0
@export var extra_right: float = 16.0
@export var extra_bottom: float = 24.0

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    get_viewport().size_changed.connect(_on_viewport_changed)
    _update_safe_area()

func _exit_tree() -> void:
    if get_viewport().size_changed.is_connected(_on_viewport_changed):
        get_viewport().size_changed.disconnect(_on_viewport_changed)

func _on_viewport_changed() -> void:
    call_deferred("_update_safe_area")

func _notification(what: int) -> void:
    if what == NOTIFICATION_RESIZED:
        call_deferred("_update_safe_area")

func _update_safe_area() -> void:
    var viewport_size := get_viewport_rect().size
    if viewport_size.x <= 1.0 or viewport_size.y <= 1.0:
        return

    var safe_rect := DisplayServer.get_display_safe_area()
    var window_size := Vector2(DisplayServer.window_get_size())
    var window_pos := Vector2(DisplayServer.window_get_position())

    if safe_rect.size.x <= 1 or safe_rect.size.y <= 1 or window_size.x <= 1 or window_size.y <= 1:
        _apply_rect(Rect2(Vector2.ZERO, viewport_size))
        return

    # DisplayServer safe-area coordinates are physical/window pixels.
    # Convert them into the logical viewport used by Control nodes.
    var local_safe_pos := Vector2(safe_rect.position) - window_pos
    var scale := Vector2(viewport_size.x / window_size.x, viewport_size.y / window_size.y)
    var logical_rect := Rect2(local_safe_pos * scale, Vector2(safe_rect.size) * scale)
    logical_rect = logical_rect.intersection(Rect2(Vector2.ZERO, viewport_size))

    if logical_rect.size.x <= 1.0 or logical_rect.size.y <= 1.0:
        logical_rect = Rect2(Vector2.ZERO, viewport_size)

    _apply_rect(logical_rect)

func _apply_rect(rect: Rect2) -> void:
    var left := min(extra_left, rect.size.x * 0.15)
    var right := min(extra_right, rect.size.x * 0.15)
    var top := min(extra_top, rect.size.y * 0.15)
    var bottom := min(extra_bottom, rect.size.y * 0.15)

    position = rect.position + Vector2(left, top)
    size = Vector2(max(1.0, rect.size.x - left - right), max(1.0, rect.size.y - top - bottom))
