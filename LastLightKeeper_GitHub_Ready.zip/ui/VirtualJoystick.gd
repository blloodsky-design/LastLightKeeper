extends Control
class_name VirtualJoystick

var touch_id := -1
var center := Vector2.ZERO
var knob := Vector2.ZERO
var radius := 65.0
var sensitivity := 1.0

func _ready() -> void:
	apply_saved_settings()
	mouse_filter = Control.MOUSE_FILTER_STOP
	queue_redraw()

func apply_saved_settings() -> void:
	var size := float(GameState.get_control_setting("joystick_size", 150.0))
	sensitivity = float(GameState.get_control_setting("joystick_sensitivity", 1.0))
	custom_minimum_size = Vector2(size, size)
	center = Vector2(size * 0.5, size * 0.5)
	radius = size * 0.43
	knob = center
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and touch_id == -1:
			touch_id = event.index
			_update_knob(event.position)
		elif not event.pressed and event.index == touch_id:
			touch_id = -1
			knob = center
			_send(Vector2.ZERO)
			queue_redraw()
	elif event is InputEventScreenDrag and event.index == touch_id:
		_update_knob(event.position)

func _update_knob(p: Vector2) -> void:
	var delta := p - center
	knob = center + delta.limit_length(radius)
	_send(((knob - center) / radius) * sensitivity)
	queue_redraw()

func _send(axis: Vector2) -> void:
	var player := get_tree().get_first_node_in_group("player") as Player
	if player:
		player.set_mobile_axis(axis)

func _draw() -> void:
	draw_circle(center, radius, Color("#ffffff",0.12))
	draw_circle(knob, min(28.0, radius * 0.43), Color("#f6d57d",0.70))
