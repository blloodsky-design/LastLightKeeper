extends Control
class_name MainMenu

signal start_requested
signal continue_requested
signal settings_requested
signal exit_requested

func refresh() -> void:
	for c in get_children(): c.queue_free()
	draw.connect(_draw_menu, CONNECT_DEFERRED)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(620, 0)
	box.add_theme_constant_override("separation", 18)
	center.add_child(box)
	var title := Label.new()
	title.text = "ХРАНИТЕЛЬ СВЕТА"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 46)
	box.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Вечные Сумерки"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 24)
	box.add_child(subtitle)
	var spacer := Control.new(); spacer.custom_minimum_size.y = 20; box.add_child(spacer)
	var new_game := _button("НОВАЯ ИГРА")
	new_game.pressed.connect(func(): start_requested.emit())
	box.add_child(new_game)
	var cont := _button("ПРОДОЛЖИТЬ")
	cont.disabled = not GameState.has_save()
	cont.pressed.connect(func(): continue_requested.emit())
	box.add_child(cont)
	var settings := _button("НАСТРОЙКИ")
	settings.pressed.connect(func(): settings_requested.emit())
	box.add_child(settings)
	var exit := _button("ВЫХОД")
	exit.pressed.connect(func(): exit_requested.emit())
	box.add_child(exit)
	var status := Label.new()
	status.text = "Сохранение найдено" if GameState.has_save() else "Новая игра — исследуй Ожерелье Света"
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(status)

func _button(t: String) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(0, 70)
	b.add_theme_font_size_override("font_size", 22)
	return b

func _draw_menu() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("#070b14"), true)
	draw_circle(size * Vector2(0.5, 0.45), min(size.x,size.y) * 0.28, Color("#d9b85c",0.06))
