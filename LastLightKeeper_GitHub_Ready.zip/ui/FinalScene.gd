extends Control
class_name FinalScene

signal closed

func setup() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center:=CenterContainer.new(); center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(center)
	var box:=VBoxContainer.new(); box.custom_minimum_size=Vector2(760,0); box.add_theme_constant_override("separation",20); center.add_child(box)
	var title:=Label.new(); title.text="ВЕЧНЫЕ СУМЕРКИ ОКОНЧЕНЫ"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",38); box.add_child(title)
	var text:=Label.new(); text.text="Чёрное Солнце Нигила погасло.\nОжерелье Света снова сияет.\n\nНо свет — не награда. Свет — выбор, который Хранитель делает каждый день."; text.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; text.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; text.add_theme_font_size_override("font_size",22); box.add_child(text)
	var stats:=Label.new(); stats.text="Уровень: %d   Побеждено боссов: %d/5   Золото: %d" % [GameState.level,GameState.defeated_bosses.size(),GameState.gold]; stats.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; box.add_child(stats)
	var hint:=Label.new(); hint.text="Последний выбор определит судьбу света."; hint.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; box.add_child(hint)
	var restore:=Button.new(); restore.text="ВЕРНУТЬ СВЕТ ВСЕМ"; restore.custom_minimum_size.y=65; restore.pressed.connect(func(): StoryManager.record_decision("nigil_final_choice", "restore", {"ending":"restore"}, {"q_black_sun":"hope"}); get_tree().change_scene_to_file("res://scenes/EndingResultScreen.tscn")); box.add_child(restore)
	var keeper:=Button.new(); keeper.text="СТАТЬ ХРАНИТЕЛЕМ СВЕТА"; keeper.custom_minimum_size.y=65; keeper.pressed.connect(func(): StoryManager.record_decision("nigil_final_choice", "keeper", {"ending":"keeper"}, {"q_black_sun":"keeper"}); get_tree().change_scene_to_file("res://scenes/EndingResultScreen.tscn")); box.add_child(keeper)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO,size),Color("#05050a"),true)
	draw_circle(size*0.5,min(size.x,size.y)*0.28,Color("#e9c965",0.08))
