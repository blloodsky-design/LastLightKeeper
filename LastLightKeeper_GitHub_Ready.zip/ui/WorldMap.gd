extends Control
class_name WorldMapView

signal zone_selected(zone_id: String)

var zones := [
	["solferino","Сольферино",Vector2(0.12,0.55)],
	["whispering_forest","Шепчущий лес",Vector2(0.31,0.36)],
	["glass_wastes","Стеклянные пустоши",Vector2(0.49,0.58)],
	["sunken_archipelago","Затонувший архипелаг",Vector2(0.68,0.35)],
	["void_citadel","Цитадель Пустоты",Vector2(0.88,0.56)]
]

func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	draw_rect(r, Color("#080d19",0.98), true)
	var pts: Array[Vector2] = []
	for z in zones:
		pts.append(Vector2(z[2]) * size)
	for i in range(pts.size()-1):
		var unlocked_next := GameState.is_zone_unlocked(zones[i+1][0])
		draw_dashed_line(pts[i], pts[i+1], Color("#e4c86b",0.75 if unlocked_next else 0.20), 5.0, 10.0)
	for i in zones.size():
		var id: String = zones[i][0]
		var p := pts[i]
		var unlocked := GameState.is_zone_unlocked(id)
		var defeated := GameState.is_boss_defeated(_boss(id))
		var radius := 34.0 if unlocked else 25.0
		draw_circle(p, radius + 12.0, Color("#e8c967",0.08) if unlocked else Color("#3a4050",0.18))
		draw_circle(p, radius, Color("#e8c967") if unlocked else Color("#303644"))
		draw_circle(p, radius - 7.0, Color("#18233a"))
		if defeated:
			draw_circle(p, 8, Color("#fff0ad"))

func _boss(zone_id: String) -> String:
	return {"solferino":"forge_guardian","whispering_forest":"root_mother","glass_wastes":"crystal_scorpion","sunken_archipelago":"tide_colossus","void_citadel":"nigil"}.get(zone_id,"")

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.pressed:
		_select(event.position)
	elif event is InputEventMouseButton and event.pressed:
		_select(event.position)

func _select(p: Vector2) -> void:
	for z in zones:
		var center := Vector2(z[2]) * size
		if center.distance_to(p) < 60.0 and GameState.is_zone_unlocked(z[0]):
			zone_selected.emit(z[0])
			return
