extends CharacterBody2D
class_name Enemy

var enemy_type := "shade"
var level := 1
var health := 40.0
var max_health := 40.0
var damage := 8.0
var speed := 55.0
var reflected := false
var attack_timer := 0.0

func _ready() -> void:
	add_to_group("enemies")
	var mult := 1.0 + float(level - 1) * 0.22
	max_health *= mult
	health = max_health
	damage *= mult
	if enemy_type == "living_shadow":
		speed = 80.0
	elif enemy_type == "mirror_wraith":
		speed = 48.0
	elif enemy_type == "drowned":
		speed = 42.0
	elif enemy_type == "voidling":
		speed = 105.0
	queue_redraw()

func _physics_process(delta: float) -> void:
	var p := get_tree().get_first_node_in_group("player") as Node2D
	if p == null:
		return
	var dir := global_position.direction_to(p.global_position)
	velocity = dir * speed
	move_and_slide()
	attack_timer -= delta
	if global_position.distance_to(p.global_position) < 48.0 and attack_timer <= 0.0:
		attack_timer = 1.1
		p.take_damage(damage)
	queue_redraw()

func take_damage(amount: float) -> void:
	if enemy_type == "mirror_wraith" and not reflected:
		return
	health -= amount
	if health <= 0.0:
		StatsManager.register_action("first_blood")
		GameState.add_experience(12 + level * 2)
		if enemy_type == "living_shadow":
			GameState.add_item("herb", 1)
		elif enemy_type == "voidling":
			GameState.add_item("dark_iron", 1)
		elif enemy_type == "drowned":
			GameState.add_item("ancient_coin", 1 if randf() < 0.25 else 0)
		if randf() < 0.35:
			GameState.add_item("light_shard", 1)
		queue_free()

func _draw() -> void:
	var c := Color("#6d7895")
	match enemy_type:
		"living_shadow": c = Color("#6f3f86")
		"mirror_wraith": c = Color("#d69bbd") if reflected else Color("#171421")
		"drowned": c = Color("#347b88")
		"voidling": c = Color("#c23e73")
	draw_circle(Vector2.ZERO, 20, c)
	draw_circle(Vector2.ZERO, 30, Color(c, 0.12))
	draw_rect(Rect2(-18,-30,36,5), Color("#160f1d"), true)
	draw_rect(Rect2(-18,-30,36 * clamp(health/max_health,0.0,1.0),5), Color("#e8c56b"), true)
